/**
 * @file Receive.h
 * @author Seb Madgwick
 * @brief Application tasks and functions for receiving messages.
 */

#ifndef RECEIVE_H
#define RECEIVE_H

//------------------------------------------------------------------------------
// Function prototypes

void ReceiveInitialise();
void ReceiveDoTasks();

#endif

//------------------------------------------------------------------------------
// End of file
