#!/bin/bash
/Applications/Max8.6.2.app/Contents/MacOS/Max '/Users/tml/Documents/GitHub/Nav/Projects/2020 10 organism/EXCITABLECHAOS/Organism.EC.device.0.31.maxpat' &

/Applications/Max8.6.2.app/Contents/MacOS/Max '/Users/tml/Documents/GitHub/Nav/Projects/2020 10 organism/EXCITABLECHAOS/ngimu/Capture/EC.Pandy.capture.maxpat'